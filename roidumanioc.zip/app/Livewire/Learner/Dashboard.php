<?php

namespace App\Livewire\Learner;

use App\Enums\EnrollmentStatus;
use App\Models\Event;
use Livewire\Attributes\Layout;
use Livewire\Component;

#[Layout('components.layouts.learner')]
class Dashboard extends Component
{
    public function render()
    {
        $user = auth()->user();

        $enrolled = $user->enrollments()
            ->where('status', EnrollmentStatus::Validee)
            ->with('formation.lessons')
            ->get();

        // Une seule requête pour toutes les leçons terminées (évite le N+1).
        $completedLessonIds = $user->lessonProgress()->pluck('lesson_id')->flip();

        return view('livewire.learner.dashboard', [
            'enrolled' => $enrolled,
            'completedLessonIds' => $completedLessonIds,
            'pending' => $user->enrollments()
                ->where('status', EnrollmentStatus::Paiement)
                ->with('formation')
                ->get(),
            'events' => Event::upcoming()->take(4)->get(),
        ]);
    }
}
