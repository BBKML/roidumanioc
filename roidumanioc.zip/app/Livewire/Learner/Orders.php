<?php

namespace App\Livewire\Learner;

use Livewire\Attributes\Layout;
use Livewire\Component;

#[Layout('components.layouts.learner')]
class Orders extends Component
{
    public function render()
    {
        $user = auth()->user();

        return view('livewire.learner.orders', [
            'payments' => $user->payments()->with('enrollment.formation')->latest('submitted_at')->get(),
            'orders' => $user->orders()->latest('ordered_at')->get(),
        ]);
    }
}
