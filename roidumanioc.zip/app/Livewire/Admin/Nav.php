<?php

namespace App\Livewire\Admin;

use App\Models\CommunityPost;
use App\Models\ContactMessage;
use App\Models\MarketplaceListing;
use App\Models\Order;
use App\Models\Payment;
use App\Models\RegistrationLead;
use Livewire\Component;

/**
 * Navigation latérale du back-office — compteurs rafraîchis en quasi-temps réel
 * (wire:poll), sans websocket.
 */
class Nav extends Component
{
    public function render()
    {
        $badges = [
            'admin.payments' => Payment::where('status', 'a_verifier')->count(),
            'admin.orders' => Order::where('status', 'validee')->count(),
            'admin.messages' => ContactMessage::where('status', 'nouveau')->count(),
            'admin.marketplace' => MarketplaceListing::where('status', 'en_attente')->count(),
            'admin.community' => CommunityPost::where('status', 'signale')->count(),
            'admin.registration-leads' => RegistrationLead::where('status', 'nouveau')->count(),
        ];

        $nav = [
            'Pilotage' => [
                ['admin.dashboard', "Vue d'ensemble", 'grid'],
                ['admin.payments', 'Paiements à vérifier', 'wallet'],
                ['admin.orders', 'Commandes', 'cart'],
                ['admin.messages', 'Messages reçus', 'chat'],
            ],
            'Contenu' => [
                ['admin.content', 'Contenu du site', 'layout'],
                ['admin.formations', 'Formations', 'book'],
                ['admin.marketplace', 'Marketplace', 'spark'],
                ['admin.shop', 'Boutique officielle', 'box'],
                ['admin.events', 'Événements', 'calendar'],
                ['admin.community', 'Communauté', 'chat'],
            ],
            'Campagnes' => [
                ['admin.registration-forms', "Formulaires d'inscription", 'link'],
                ['admin.registration-leads', 'Prospects', 'users'],
            ],
            'Gestion' => [
                ['admin.members', 'Membres', 'users'],
                ['admin.newsletter', 'Infolettre', 'spark'],
                ['admin.activity', "Journal d'activité", 'grid'],
                ['admin.settings', 'Paramètres', 'gear'],
                ['account.edit', 'Mon compte', 'users'],
            ],
        ];

        return view('livewire.admin.nav', [
            'nav' => $nav,
            'badges' => $badges,
            'current' => request()->route()?->getName(),
        ]);
    }
}
