<?php

namespace App\Livewire\Admin;

use App\Enums\FormationStatus;
use App\Models\Formation;
use Livewire\Attributes\Layout;
use Livewire\Component;

#[Layout('components.layouts.admin')]
class Formations extends Component
{
    public bool $showForm = false;
    public ?int $editingId = null;

    public string $title = '';
    public string $category = '';
    public ?string $description = null;
    public int $price = 0;
    public string $status = 'brouillon';
    public ?string $image_path = null;
    public ?string $duration_label = null;

    protected function rules(): array
    {
        return [
            'title' => ['required', 'string', 'max:160'],
            'category' => ['required', 'string', 'max:60'],
            'description' => ['nullable', 'string', 'max:2000'],
            'price' => ['required', 'integer', 'min:0'],
            'status' => ['required', 'in:brouillon,publiee'],
            'image_path' => ['nullable', 'string', 'max:255'],
            'duration_label' => ['nullable', 'string', 'max:40'],
        ];
    }

    public function new(): void
    {
        $this->reset('editingId', 'title', 'category', 'description', 'image_path', 'duration_label');
        $this->price = 0;
        $this->status = 'brouillon';
        $this->resetValidation();
        $this->showForm = true;
    }

    public function edit(int $formationId): void
    {
        $formation = Formation::findOrFail($formationId);
        $this->editingId = $formation->id;
        $this->title = $formation->title;
        $this->category = (string) $formation->category;
        $this->description = $formation->description;
        $this->price = $formation->price;
        $this->status = $formation->status->value;
        $this->image_path = $formation->image_path;
        $this->duration_label = $formation->duration_label;
        $this->resetValidation();
        $this->showForm = true;
    }

    public function save(): void
    {
        $data = $this->validate();

        if ($this->editingId) {
            Formation::findOrFail($this->editingId)->update($data);
            $message = 'Formation mise à jour.';
        } else {
            $data['position'] = (int) Formation::max('position') + 1;
            Formation::create($data);
            $message = 'Formation créée.';
        }

        $this->showForm = false;
        $this->dispatch('notify', message: $message);
    }

    public function togglePublish(int $formationId): void
    {
        $formation = Formation::findOrFail($formationId);
        $formation->update([
            'status' => $formation->status === FormationStatus::Publiee
                ? FormationStatus::Brouillon
                : FormationStatus::Publiee,
        ]);
    }

    public function delete(int $formationId): void
    {
        $formation = Formation::findOrFail($formationId);
        $formation->delete();
        $this->dispatch('notify', message: 'Formation supprimée.');
    }

    public function render()
    {
        return view('livewire.admin.formations', [
            'formations' => Formation::withCount([
                'lessons',
                'enrollments as validated_count' => fn ($q) => $q->where('status', 'validee'),
            ])->orderBy('position')->get(),
            'statuses' => FormationStatus::cases(),
        ]);
    }
}
