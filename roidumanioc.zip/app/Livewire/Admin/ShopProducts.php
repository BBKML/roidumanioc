<?php

namespace App\Livewire\Admin;

use App\Models\ShopProduct;
use Livewire\Attributes\Layout;
use Livewire\Component;

#[Layout('components.layouts.admin')]
class ShopProducts extends Component
{
    public bool $showForm = false;
    public ?int $editingId = null;

    public string $name = '';
    public string $category = '';
    public int $price = 0;
    public int $stock = 0;
    public ?string $description = null;
    public ?string $image_path = null;
    public bool $is_active = true;

    protected function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:160'],
            'category' => ['required', 'string', 'max:60'],
            'price' => ['required', 'integer', 'min:0'],
            'stock' => ['required', 'integer', 'min:0'],
            'description' => ['nullable', 'string', 'max:2000'],
            'image_path' => ['nullable', 'string', 'max:255'],
            'is_active' => ['boolean'],
        ];
    }

    public function new(): void
    {
        $this->reset('editingId', 'name', 'category', 'description', 'image_path');
        $this->price = 0;
        $this->stock = 0;
        $this->is_active = true;
        $this->resetValidation();
        $this->showForm = true;
    }

    public function edit(ShopProduct $product): void
    {
        $this->editingId = $product->id;
        $this->name = $product->name;
        $this->category = $product->category;
        $this->price = $product->price;
        $this->stock = $product->stock;
        $this->description = $product->description;
        $this->image_path = $product->image_path;
        $this->is_active = $product->is_active;
        $this->resetValidation();
        $this->showForm = true;
    }

    public function save(): void
    {
        $data = $this->validate();

        if ($this->editingId) {
            ShopProduct::findOrFail($this->editingId)->update($data);
            $message = 'Produit mis à jour.';
        } else {
            $data['position'] = (int) ShopProduct::max('position') + 1;
            ShopProduct::create($data);
            $message = 'Produit ajouté.';
        }

        $this->showForm = false;
        $this->dispatch('notify', message: $message);
    }

    public function toggleActive(ShopProduct $product): void
    {
        $product->update(['is_active' => ! $product->is_active]);
    }

    public function delete(ShopProduct $product): void
    {
        $product->delete();
        $this->dispatch('notify', message: 'Produit supprimé.');
    }

    public function render()
    {
        return view('livewire.admin.shop-products', [
            'products' => ShopProduct::orderBy('position')->orderBy('name')->get(),
        ]);
    }
}
