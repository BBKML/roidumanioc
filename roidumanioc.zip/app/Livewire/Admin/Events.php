<?php

namespace App\Livewire\Admin;

use App\Enums\EventStatus;
use App\Models\Event;
use Livewire\Attributes\Layout;
use Livewire\Component;

#[Layout('components.layouts.admin')]
class Events extends Component
{
    public bool $showForm = false;
    public ?int $editingId = null;

    public string $title = '';
    public string $date_label = '';
    public ?string $starts_at = null;
    public string $type = 'Live';
    public string $status = 'planifie';
    public ?string $link = null;
    public ?string $description = null;

    protected function rules(): array
    {
        return [
            'title' => ['required', 'string', 'max:160'],
            'date_label' => ['nullable', 'string', 'max:60'],
            'starts_at' => ['nullable', 'date'],
            'type' => ['required', 'string', 'max:40'],
            'status' => ['required', 'in:planifie,termine'],
            'link' => ['nullable', 'url', 'max:255'],
            'description' => ['nullable', 'string', 'max:2000'],
        ];
    }

    public function new(): void
    {
        $this->reset('editingId', 'title', 'date_label', 'starts_at', 'link', 'description');
        $this->type = 'Live';
        $this->status = 'planifie';
        $this->resetValidation();
        $this->showForm = true;
    }

    public function edit(Event $event): void
    {
        $this->editingId = $event->id;
        $this->title = $event->title;
        $this->date_label = (string) $event->date_label;
        $this->starts_at = $event->starts_at?->format('Y-m-d');
        $this->type = $event->type;
        $this->status = $event->status->value;
        $this->link = $event->link;
        $this->description = $event->description;
        $this->resetValidation();
        $this->showForm = true;
    }

    public function save(): void
    {
        $data = $this->validate();

        if ($this->editingId) {
            Event::findOrFail($this->editingId)->update($data);
            $message = 'Événement mis à jour.';
        } else {
            $data['position'] = (int) Event::max('position') + 1;
            Event::create($data);
            $message = 'Événement créé.';
        }

        $this->showForm = false;
        $this->dispatch('notify', message: $message);
    }

    public function delete(Event $event): void
    {
        $event->delete();
        $this->dispatch('notify', message: 'Événement supprimé.');
    }

    public function render()
    {
        return view('livewire.admin.events', [
            'events' => Event::orderByRaw('starts_at is null')->orderBy('starts_at')->orderBy('position')->get(),
            'statuses' => EventStatus::cases(),
        ]);
    }
}
