<?php

namespace App\Livewire\Admin;

use App\Enums\OrderStatus;
use App\Models\ContactMessage;
use App\Models\Enrollment;
use App\Models\Formation;
use App\Models\MarketplaceListing;
use App\Models\Order;
use App\Models\Payment;
use App\Models\User;
use Illuminate\Support\Carbon;
use Livewire\Attributes\Layout;
use Livewire\Component;

#[Layout('components.layouts.admin')]
class Dashboard extends Component
{
    public function render()
    {
        $toVerify = Payment::toVerify()->with('user')->latest('submitted_at')->get();

        // Inscriptions validées, regroupées par mois sur les 5 derniers mois.
        $bars = collect(range(4, 0))->map(function (int $back) {
            $month = Carbon::now()->startOfMonth()->subMonths($back);

            return [
                'label' => ucfirst($month->translatedFormat('M')),
                'value' => Enrollment::where('status', 'validee')
                    ->whereBetween('enrolled_at', [$month, (clone $month)->endOfMonth()])
                    ->count(),
            ];
        });

        $revenueOnline = (int) Payment::where('status', 'confirme')->sum('amount');
        $revenueDelivery = (int) Order::where('status', OrderStatus::Livree)
            ->where('payment_mode', 'on_delivery')
            ->get()
            ->sum(fn (Order $o) => $o->total());

        return view('livewire.admin.dashboard', [
            'activeMembers' => User::where('status', 'actif')->count(),
            'publishedFormations' => Formation::published()->count(),
            'totalFormations' => Formation::count(),
            'pendingListings' => MarketplaceListing::where('status', 'en_attente')->count(),
            'toVerify' => $toVerify,
            'revenueOnline' => $revenueOnline,
            'revenueDelivery' => $revenueDelivery,
            'revenue' => $revenueOnline + $revenueDelivery,
            'ordersToPrepare' => Order::where('status', OrderStatus::Validee)->count(),
            'ordersInDelivery' => Order::where('status', OrderStatus::Expediee)->count(),
            'newMessages' => ContactMessage::inbox()->count(),
            'bars' => $bars,
        ]);
    }
}
