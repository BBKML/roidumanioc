<?php

namespace App\Livewire\Admin;

use App\Models\RegistrationForm;
use App\Models\RegistrationLead;
use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Livewire\WithPagination;

#[Layout('components.layouts.admin')]
class RegistrationLeads extends Component
{
    use WithPagination;

    public string $search = '';
    public string $formId = '';
    public string $filter = 'nouveau';
    public ?int $openId = null;
    public string $note = '';

    public function updatingSearch(): void
    {
        $this->resetPage();
    }

    public function updatingFormId(): void
    {
        $this->resetPage();
    }

    public function setFilter(string $filter): void
    {
        $this->filter = $filter;
        $this->resetPage();
    }

    public function open(int $id): void
    {
        $this->openId = $this->openId === $id ? null : $id;
        $this->note = $this->openId ? (RegistrationLead::find($id)->admin_note ?? '') : '';
    }

    public function saveNote(int $id): void
    {
        RegistrationLead::findOrFail($id)->update(['admin_note' => $this->note]);
        $this->dispatch('notify', message: 'Note enregistrée.');
    }

    public function markContacted(int $id): void
    {
        RegistrationLead::findOrFail($id)->markContacted(Auth::user());
    }

    public function markEnrolled(int $id): void
    {
        RegistrationLead::findOrFail($id)->markEnrolled(Auth::user());
    }

    public function markAbandoned(int $id): void
    {
        RegistrationLead::findOrFail($id)->markAbandoned(Auth::user());
    }

    public function reopen(int $id): void
    {
        RegistrationLead::findOrFail($id)->reopen();
    }

    public function delete(int $id): void
    {
        RegistrationLead::findOrFail($id)->delete();
        $this->dispatch('notify', message: 'Prospect supprimé.');
    }

    private function counts(): array
    {
        return [
            'nouveau' => RegistrationLead::where('status', 'nouveau')->count(),
            'contacte' => RegistrationLead::where('status', 'contacte')->count(),
            'inscrit' => RegistrationLead::where('status', 'inscrit')->count(),
            'abandonne' => RegistrationLead::where('status', 'abandonne')->count(),
        ];
    }

    public function render()
    {
        $query = RegistrationLead::with('registrationForm')->latest();

        if ($this->filter !== 'tous') {
            $query->where('status', $this->filter);
        }

        if ($this->formId !== '') {
            $query->where('registration_form_id', $this->formId);
        }

        if ($this->search !== '') {
            $query->where(fn ($q) => $q
                ->where('first_name', 'like', "%{$this->search}%")
                ->orWhere('last_name', 'like', "%{$this->search}%")
                ->orWhere('email', 'like', "%{$this->search}%")
                ->orWhere('phone_1', 'like', "%{$this->search}%"));
        }

        return view('livewire.admin.registration-leads', [
            'leads' => $query->paginate(15),
            'forms' => RegistrationForm::orderBy('title')->get(),
            'counts' => $this->counts(),
        ]);
    }
}
