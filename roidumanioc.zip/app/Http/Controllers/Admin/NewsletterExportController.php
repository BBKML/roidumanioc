<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\NewsletterSubscriber;
use Symfony\Component\HttpFoundation\StreamedResponse;

class NewsletterExportController extends Controller
{
    public function __invoke(): StreamedResponse
    {
        $filename = 'infolettre-'.now()->format('Y-m-d').'.csv';

        return response()->streamDownload(function () {
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF"); // BOM UTF-8 pour Excel
            fputcsv($out, ['email', 'source', 'inscrit_le']);

            NewsletterSubscriber::active()->orderBy('email')->chunk(500, function ($chunk) use ($out) {
                foreach ($chunk as $sub) {
                    fputcsv($out, [$sub->email, $sub->source, $sub->created_at->toDateString()]);
                }
            });

            fclose($out);
        }, $filename, ['Content-Type' => 'text/csv']);
    }
}
