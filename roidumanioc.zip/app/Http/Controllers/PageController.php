<?php

namespace App\Http\Controllers;

use App\Models\Award;
use App\Models\SiteContent;
use App\Models\Testimonial;

/**
 * Petites pages publiques dédiées, autrefois de simples ancres sur l'accueil — mêmes données
 * (CMS + modèles), mais avec leur propre URL indexable et partageable.
 */
class PageController extends Controller
{
    public function placali()
    {
        return view('pages.placali', [
            'content' => SiteContent::section('placali', []),
        ]);
    }

    public function communaute()
    {
        return view('pages.communaute', [
            'content' => SiteContent::section('communaute', []),
            'testimonials' => Testimonial::published()->get(),
        ]);
    }

    public function fondateur()
    {
        return view('pages.fondateur', [
            'content' => SiteContent::section('fondateur', []),
            'distinctions' => SiteContent::section('distinctions', []),
            'awards' => Award::published()->get(),
        ]);
    }
}
