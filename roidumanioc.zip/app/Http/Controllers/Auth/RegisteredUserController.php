<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Mail\NewMemberMail;
use App\Models\User;
use App\Support\PhoneNumber;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     */
    public function create(): View
    {
        return view('auth.register');
    }

    /**
     * Handle an incoming registration request.
     *
     * Beaucoup de clients n'ont pas d'e-mail mais ont tous un téléphone :
     * l'un des deux suffit (required_without), le champ « login » retenu
     * détermine ensuite comment l'utilisateur pourra se reconnecter.
     *
     * @throws ValidationException
     */
    public function store(Request $request): RedirectResponse
    {
        $request->merge(['phone' => PhoneNumber::normalize($request->input('phone'))]);

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'email' => ['nullable', 'required_without:phone', 'string', 'lowercase', 'email', 'max:180', Rule::unique(User::class, 'email')],
            'phone' => ['nullable', 'required_without:email', 'string', 'max:20', Rule::unique(User::class, 'phone')],
            'city' => ['nullable', 'string', 'max:120'],
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
        ]);

        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'] ?? null,
            'phone' => $validated['phone'] ?? null,
            'city' => $validated['city'] ?? null,
            'password' => Hash::make($validated['password']),
            'password_changed_at' => now(),
            'joined_at' => now(),
            // role / status : valeurs par défaut de la base (apprenant / actif) — jamais depuis la requête.
        ]);

        event(new Registered($user));

        try {
            $adminEmail = User::query()->activeAdmins()->value('email') ?: config('mail.from.address');
            Mail::to($adminEmail)->send(new NewMemberMail($user));
        } catch (\Throwable $e) {
            report($e);
        }

        Auth::login($user);

        return redirect(route('dashboard', absolute: false));
    }
}
