<?php

namespace App\Http\Controllers;

use App\Models\MarketplaceListing;
use App\Models\ShopProduct;
use App\Models\SiteContent;

class MarketplaceController extends Controller
{
    public function index()
    {
        $listings = MarketplaceListing::published()->latest()->get();
        $products = ShopProduct::active()->orderBy('position')->get();

        // Même forme unifiée que l'aperçu de l'accueil (HomeController) : offres des
        // producteurs + boutique officielle dans une seule grille, sans limite ici.
        $offers = $listings->map(fn (MarketplaceListing $l) => [
            'label' => $l->type,
            'title' => $l->title,
            'location' => $l->location,
            'price' => $l->price_label,
            'image' => $l->image_path,
        ])->concat($products->map(fn (ShopProduct $p) => [
            'label' => 'Boutique officielle',
            'title' => $p->name,
            'location' => 'Le Roi du Manioc',
            'price' => number_format($p->price, 0, ',', ' ').' FCFA',
            'image' => $p->image_path,
        ]))->values();

        return view('marketplace.index', [
            'offers' => $offers,
            'section' => SiteContent::section('marketplace_section', []),
        ]);
    }
}
