<?php

namespace App\Http\Requests;

use App\Http\Controllers\RegistrationFormController;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreRegistrationLeadRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'gender' => ['required', 'string', 'in:Homme,Femme'],
            'last_name' => ['required', 'string', 'max:100'],
            'first_name' => ['required', 'string', 'max:100'],
            'email' => ['nullable', 'email', 'max:180'],
            'phone_1' => ['required', 'string', 'max:40'],
            'phone_2' => ['nullable', 'string', 'max:40'],
            'whatsapp' => ['required', 'string', 'max:40'],
            'country_code' => ['nullable', 'string', 'max:20'],
            'experience_level' => ['required', Rule::in(RegistrationFormController::EXPERIENCE_LEVELS)],
            'profession' => ['required', Rule::in(RegistrationFormController::STATUS_FUNCTIONS)],
            'profession_other' => ['nullable', 'string', 'max:160', 'required_if:profession,Autre'],
            'age_range' => ['required', Rule::in(RegistrationFormController::AGE_RANGES)],
            'company' => ['nullable', 'string', 'max:160'],
            'city_country' => ['required', 'string', 'max:160'],
            'motivations' => ['nullable', 'array'],
            'motivations.*' => ['string', 'max:160'],
            'motivation_other' => ['nullable', 'string', 'max:160'],
            'expectations' => ['nullable', 'string', 'max:2000'],
            'how_heard' => ['nullable', 'string', 'max:120'],
            'payment_method' => ['required', 'string', 'max:120'],
            'payment_frequency' => ['nullable', 'string', 'max:160'],
            // Anti-spam : champ caché qui doit rester vide (honeypot).
            'website' => ['prohibited'],
        ];
    }

    public function attributes(): array
    {
        return [
            'gender' => 'genre',
            'last_name' => 'nom',
            'first_name' => 'prénoms',
            'email' => 'e-mail',
            'phone_1' => 'numéro de téléphone',
            'whatsapp' => 'numéro WhatsApp',
            'experience_level' => 'niveau d\'expérience',
            'profession' => 'statut / fonction',
            'profession_other' => 'statut / fonction (précision)',
            'age_range' => 'tranche d\'âge',
            'company' => 'entreprise ou organisation',
            'city_country' => 'ville et pays de résidence',
            'payment_method' => 'moyen de paiement',
        ];
    }
}
