<?php

namespace App\Providers;

use App\Http\Middleware\EnsureUserIsActive;
use App\Http\Middleware\EnsureUserIsAdmin;
use App\Models\User;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;
use Illuminate\Validation\Rules\Password;
use Livewire\Livewire;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Un administrateur actif passe toutes les autorisations.
        Gate::before(function (User $user, string $ability) {
            if ($user->isAdmin() && $user->isActive()) {
                return true;
            }

            return null;
        });

        // Les requêtes Livewire (wire:click…) ne rejouent pas le middleware de route par défaut.
        // On force la re-vérification du rôle / du statut à chaque mise à jour de composant.
        Livewire::addPersistentMiddleware([
            EnsureUserIsAdmin::class,
            EnsureUserIsActive::class,
        ]);

        // Politique de mot de passe : 8+ caractères, lettres et chiffres.
        // En production on refuse aussi les mots de passe connus des fuites (base HIBP).
        Password::defaults(fn () => Password::min(8)
            ->letters()
            ->numbers()
            ->when($this->app->isProduction(), fn (Password $rule) => $rule->uncompromised()));

        // Pagination du back-office : gabarit maison (le CSS admin n'est pas Tailwind).
        Paginator::defaultView('vendor.pagination.adm');
        Paginator::defaultSimpleView('vendor.pagination.adm');
    }
}
