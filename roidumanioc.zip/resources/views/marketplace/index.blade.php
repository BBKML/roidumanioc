@php
    $img = fn ($path, $fallback = 'img/champ-manioc.jpg') => asset($path ?: $fallback);
@endphp
<x-public-layout :title="$section['title'] ?? 'Marketplace'" :description="$section['lead'] ?? null">

<main id="main">
<span id="top"></span>

<section class="section">
  <div class="wrap">
    <div class="contact-wrap">
      <p class="eyebrow">{{ $section['eyebrow'] ?? 'Marketplace' }}</p>
      <h1>{{ $section['title'] ?? 'Le marché du manioc, en confiance.' }}</h1>
      <p class="contact-lead">{{ $section['lead'] ?? '' }}</p>
    </div>
  </div>
</section>

<section class="section market">
  <div class="wrap">
    <div class="offers">
      @forelse ($offers as $offer)
        <article class="offer">
          <div class="ph"><img loading="lazy" decoding="async" src="{{ $img($offer['image']) }}" alt="{{ $offer['title'] }}"></div>
          <div class="ob">
            <span class="t">{{ $offer['label'] }}</span>
            <h4>{{ $offer['title'] }}</h4>
            <p class="loc">{{ $offer['location'] }}</p>
            <div class="ofoot">
              <span class="p">{{ $offer['price'] }}</span>
              <a href="{{ route('login') }}" class="order">{{ __('site.marketplace.order_button') }}</a>
            </div>
          </div>
        </article>
      @empty
        <p class="muted">Aucune offre disponible pour le moment.</p>
      @endforelse
    </div>
  </div>
</section>

</main>

</x-public-layout>
