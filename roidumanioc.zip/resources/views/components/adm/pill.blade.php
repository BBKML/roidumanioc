@props(['status'])
@php
    $value = $status instanceof \BackedEnum ? $status->value : $status;
    $label = ($status instanceof \BackedEnum && method_exists($status, 'label')) ? $status->label() : \Illuminate\Support\Str::headline((string) $value);

    $map = [
        // formations / enrollments / orders
        'publiee' => 'ok', 'validee' => 'ok', 'confirme' => 'ok', 'actif' => 'ok', 'livree' => 'ok', 'inscrit' => 'ok',
        'expediee' => 'info',
        'brouillon' => 'neutral', 'masque' => 'neutral', 'termine' => 'neutral',
        'a_verifier' => 'warn', 'paiement' => 'warn', 'en_attente' => 'warn', 'planifie' => 'warn', 'signale' => 'warn', 'suspendu' => 'warn', 'nouveau' => 'warn',
        'contacte' => 'info',
        'refuse' => 'danger', 'abandonne' => 'danger',
        'visible' => 'ok',
    ];
    $cls = $map[$value] ?? 'neutral';
@endphp
<span {{ $attributes->merge(['class' => "pill $cls"]) }}><span class="dot"></span>{{ $label }}</span>
