@props(['code'])

@if ($code === 'fr')
  <svg viewBox="0 0 3 2" width="22" height="16" aria-hidden="true">
    <rect width="1" height="2" fill="#002395"/>
    <rect x="1" width="1" height="2" fill="#fff"/>
    <rect x="2" width="1" height="2" fill="#ED2939"/>
  </svg>
@elseif ($code === 'en')
  <svg viewBox="0 0 60 30" width="22" height="16" aria-hidden="true">
    <rect width="60" height="30" fill="#012169"/>
    <path d="M0,0 L60,30 M60,0 L0,30" stroke="#fff" stroke-width="6"/>
    <path d="M0,0 L60,30 M60,0 L0,30" stroke="#C8102E" stroke-width="2"/>
    <path d="M30,0 V30 M0,15 H60" stroke="#fff" stroke-width="10"/>
    <path d="M30,0 V30 M0,15 H60" stroke="#C8102E" stroke-width="6"/>
  </svg>
@endif
