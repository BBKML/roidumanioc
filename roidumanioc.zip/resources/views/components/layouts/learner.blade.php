@php
    use App\Models\Event;

    $current = request()->route()?->getName();
    $user = auth()->user();

    $nav = [
        'Ma formation' => [
            ['learner.dashboard', 'Mon espace', 'home'],
            ['learner.catalog', 'Catalogue', 'book'],
            ['learner.progress', 'Ma progression', 'award'],
        ],
        'Le royaume' => [
            ['learner.marketplace', 'Marketplace', 'spark'],
            ['learner.orders', 'Mes commandes', 'cart'],
            ['learner.community', 'Communauté', 'chat'],
        ],
        'Compte' => [
            ['account.edit', 'Mon compte', 'users'],
        ],
    ];

    $titles = [
        'learner.dashboard' => ['Espace apprenant', 'Mon espace'],
        'learner.catalog' => ['Espace apprenant', 'Catalogue des formations'],
        'learner.course' => ['Espace apprenant', 'Formation'],
        'learner.progress' => ['Espace apprenant', 'Ma progression'],
        'learner.marketplace' => ['Espace apprenant', 'Marketplace'],
        'learner.orders' => ['Espace apprenant', 'Mes commandes'],
        'learner.community' => ['Espace apprenant', 'Communauté'],
        'learner.checkout' => ['Espace apprenant', 'Finaliser le paiement'],
        'learner.shop-checkout' => ['Espace apprenant', 'Finaliser la commande'],
        'account.edit' => ['Compte', 'Mon compte'],
    ];
    [$crumb, $pageTitle] = $titles[$current] ?? ['Espace apprenant', 'Espace apprenant'];

    $icons = [
        'home' => '<path d="M4 11l8-7 8 7M6 10v10h12V10"/>',
        'book' => '<path d="M4 4v16l7-2 7 2V4l-7 2-7-2z"/><path d="M11 6v14"/>',
        'award' => '<circle cx="12" cy="9" r="6"/><path d="M9 14l-2 7 5-3 5 3-2-7"/>',
        'spark' => '<path d="M12 3v6M12 15v6M3 12h6M15 12h6"/>',
        'cart' => '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.5 13h11L21 7H6"/>',
        'chat' => '<path d="M4 5h16v11H9l-4 4V5z"/>',
        'users' => '<circle cx="9" cy="8" r="3.2"/><path d="M3.5 20c.7-3.4 3-5 5.5-5s4.8 1.6 5.5 5"/><path d="M16 5.5a3 3 0 0 1 0 5.6M17.5 20c-.3-2-1-3.5-2-4.5"/>',
    ];
    $svg = fn ($k) => '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'.($icons[$k] ?? '').'</svg>';
@endphp
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>{{ $pageTitle }} — Espace apprenant · Le Roi du Manioc</title>
<link rel="icon" href="{{ asset('img/logo.png') }}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,500;0,9..144,600;1,9..144,500&family=Manrope:wght@400;500;600;700;800&display=swap">
@vite(['resources/css/admin.css', 'resources/js/admin.js'])
@livewireStyles
</head>
<body>
<div class="layout">
  <aside class="sidebar" id="sidebar">
    <a class="brand" href="{{ route('home') }}" title="Retour au site public">
      <img src="{{ asset('img/logo.png') }}" alt="">
      <span class="brand-txt"><b>Le Roi du Manioc</b><span class="brand-tag">Espace apprenant</span></span>
    </a>

    <div class="side-user">
      <span class="avatar">{{ $user?->initials() }}</span>
      <span class="su-txt">
        <b>{{ $user?->name }}</b>
        <span class="su-role">Apprenant</span>
      </span>
    </div>

    <nav id="nav">
      @foreach ($nav as $group => $items)
        <div class="nav-label">{{ $group }}</div>
        @foreach ($items as [$route, $label, $icon])
          <a class="nav-item {{ $current === $route ? 'on' : '' }}" href="{{ route($route) }}" wire:navigate>
            {!! $svg($icon) !!}<span>{{ $label }}</span>
          </a>
        @endforeach
      @endforeach
    </nav>

    <div class="sidebar-foot">
      <a href="{{ route('home') }}" class="foot-site">← Voir le site public</a>
      <form method="POST" action="{{ route('logout') }}" style="margin-top:.7rem">
        @csrf
        <button type="submit">Se déconnecter</button>
      </form>
    </div>
  </aside>

  <div class="main">
    <header class="topbar">
      <button class="burger" id="burger" aria-label="Menu">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
      </button>
      <div>
        <div class="crumb">{{ $crumb }}</div>
        <h1>{{ $pageTitle }}</h1>
      </div>
      <div class="sp"></div>
      <span class="chip"><span class="avatar">{{ $user?->initials() }}</span><span class="muted">{{ $user?->name }}</span></span>
    </header>

    <div class="view">
      {{ $slot }}
    </div>
  </div>
</div>

<div class="drawer-back" id="drawerBack"></div>

<x-adm.confirm-dialog />

@if (session('flash'))
  <div class="lw-flash">{{ session('flash') }}</div>
@endif

@livewireScripts
</body>
</html>
