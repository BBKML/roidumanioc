@php $user = auth()->user(); @endphp
<div style="display:flex;flex-direction:column;gap:1.4rem">

  <div class="page-intro">
    <div>
      <h2>Bonjour {{ \Illuminate\Support\Str::of($user->name)->explode(' ')->first() }} 🌱</h2>
      <p>Reprenez votre apprentissage là où vous vous êtes arrêté.</p>
    </div>
    <a class="btn ghost" href="{{ route('learner.catalog') }}" wire:navigate>
      <svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4v16l7-2 7 2V4l-7 2-7-2z"/></svg>
      Parcourir le catalogue
    </a>
  </div>

  @if ($enrolled->isNotEmpty())
    <div class="grid g-2">
      @foreach ($enrolled as $enrollment)
        @php
          $f = $enrollment->formation;
          $total = $f->lessons->count();
          $done = $f->lessons->filter(fn ($l) => $completedLessonIds->has($l->id))->count();
          $pr = ['done' => $done, 'total' => $total, 'pct' => $total ? (int) round($done / $total * 100) : 0];
          $next = $f->lessons->first(fn ($l) => ! $completedLessonIds->has($l->id));
        @endphp
        <div class="card pad-lg" wire:key="enr-{{ $enrollment->id }}">
          <div style="display:flex;gap:1rem">
            @if ($f->image_path)
              <img src="{{ asset($f->image_path) }}" alt="" style="width:96px;height:72px;border-radius:10px;object-fit:cover;object-position:center 20%;flex:none">
            @endif
            <div style="min-width:0">
              <h3 style="font-size:1.05rem">{{ $f->title }}</h3>
              <p class="muted" style="margin:.2rem 0 0;font-size:.8rem">{{ $pr['done'] }}/{{ $pr['total'] }} leçons · {{ $pr['pct'] }}%</p>
            </div>
          </div>
          <div class="progress" style="margin:1rem 0 .8rem"><i style="width:{{ $pr['pct'] }}%"></i></div>
          <div style="display:flex;justify-content:space-between;align-items:center;gap:.6rem;flex-wrap:wrap">
            <span class="muted" style="font-size:.8rem">{{ $next ? 'Suivant : '.$next->title : 'Formation terminée 🎉' }}</span>
            <a class="btn sm" href="{{ route('learner.course', $f) }}" wire:navigate>{{ $pr['pct'] ? 'Continuer' : 'Commencer' }}</a>
          </div>
        </div>
      @endforeach
    </div>
  @else
    <div class="card"><div class="empty">
      <svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4v16l7-2 7 2V4l-7 2-7-2z"/></svg>
      <p>Vous ne suivez encore aucune formation.</p>
      <a class="btn" href="{{ route('learner.catalog') }}" wire:navigate style="margin-top:.6rem">Voir le catalogue</a>
    </div></div>
  @endif

  @if ($pending->isNotEmpty())
    <div class="card">
      <div class="card-head"><h3>Paiement en cours de vérification</h3></div>
      @foreach ($pending as $enrollment)
        <div style="display:flex;justify-content:space-between;align-items:center;padding:.5rem 0">
          <span>{{ $enrollment->formation->title }}</span>
          <x-adm.pill :status="$enrollment->status" />
        </div>
      @endforeach
      <p class="muted" style="font-size:.78rem;margin:.6rem 0 0">Votre accès s'active dès que notre équipe a vérifié le paiement (généralement sous quelques heures).</p>
    </div>
  @endif

  <div class="card">
    <div class="card-head"><h3>Prochains événements</h3><a class="link-btn" href="{{ route('learner.community') }}" wire:navigate>Communauté →</a></div>
    @if ($events->isNotEmpty())
      <ul class="activity reset">
        @foreach ($events as $event)
          <li>
            <span class="di"><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg></span>
            <div><b>{{ $event->title }}</b><br><time>{{ $event->date_label ?: $event->starts_at?->format('d/m/Y') }} · {{ $event->type }}</time></div>
          </li>
        @endforeach
      </ul>
    @else
      <p class="muted" style="font-size:.82rem">Aucun événement programmé pour l'instant.</p>
    @endif
  </div>

</div>
