{{-- Vitrine — portée de la maquette index.html (design validé). 100 % base de données. --}}
<x-public-layout>

@php
    $hero        = $content['hero'] ?? [];
    $bandeau     = $content['bandeau'] ?? [];
    $mission     = $content['mission'] ?? [];
    $chiffres    = $content['chiffres']['items'] ?? [];
    $piliers     = $content['piliers'] ?? [];
    $placali     = $content['placali'] ?? [];
    $fSection    = $content['formations_section'] ?? [];
    $mSection    = $content['marketplace_section'] ?? [];
    $communaute  = $content['communaute'] ?? [];
    $distinctions = $content['distinctions'] ?? [];
    $fondateur   = $content['fondateur'] ?? [];
    $ctaFinal    = $content['cta'] ?? [];

    $img = fn ($path, $fallback = 'img/champ-manioc.jpg') => asset($path ?: $fallback);
    $fcfa = fn ($n) => number_format((int) $n, 0, ',', ' ').' FCFA';
    $initials = fn ($name) => \Illuminate\Support\Str::of($name)
        ->explode(' ')
        ->filter()
        ->map(fn ($w) => \Illuminate\Support\Str::upper(\Illuminate\Support\Str::substr($w, 0, 1)))
        ->take(2)
        ->implode('');

    // Liens fixes des 4 piliers (structure de navigation, pas du contenu éditorial).
    $piliersLinks = [
        [route('formations.index'), __('site.pillar_links.formations')],
        [route('marketplace.index'), __('site.pillar_links.marketplace')],
        [route('marketplace.index'), __('site.pillar_links.shop')],
        [route('placali.show'), __('site.pillar_links.placali')],
    ];
@endphp

<main id="main">
<span id="top"></span>

<section class="hero">
  <div class="hero-grid">
    <div class="hero-copy">
      <p class="eyebrow">{{ $hero['eyebrow'] ?? '' }}</p>
      <h1>{!! $hero['title_html'] ?? e($hero['title'] ?? '') !!}</h1>
      <p class="lead">{{ $hero['text'] ?? '' }}</p>
      <div class="hero-actions">
        <a href="#placali" class="btn">{{ $hero['button1'] ?? 'Découvrir le Placali du Roi' }}</a>
        <a href="{{ route('login') }}" class="btn ghost">{{ $hero['button2'] ?? 'Accéder aux formations' }}</a>
      </div>
      <div class="hero-trust">
        @foreach (($hero['trust'] ?? []) as $item)
          <span class="dot"></span><span>{{ $item }}</span>
        @endforeach
      </div>
    </div>
    <div class="hero-media">
      <svg class="crown" viewBox="0 0 64 44" fill="currentColor" aria-hidden="true"><path d="M4 40h56l-4-24-13 9-11-19-11 19-13-9z"/></svg>
      <div class="frame">
        <img src="{{ $img(data_get($hero, 'image.src')) }}" alt="{{ data_get($hero, 'image.alt', '') }}">
      </div>
      <div class="hero-portrait">
        <img src="{{ $img(data_get($hero, 'portrait.src'), 'img/fondateur-portrait.jpg') }}" alt="{{ data_get($hero, 'portrait.alt', '') }}">
      </div>
    </div>
  </div>
</section>

<section class="press" aria-label="Distinctions et partenaires">
  <div class="wrap">
    <span>{{ __('site.press.trusted_by') }}</span>
    @foreach (($bandeau['items'] ?? []) as $item)
      <span>{{ $item }}</span>
    @endforeach
  </div>
</section>

<section class="section" id="mission">
  <div class="wrap">
    <div class="mission">
      <div>
        <p class="eyebrow">{{ $mission['eyebrow'] ?? '' }}</p>
        <h2>{{ $mission['title'] ?? '' }}</h2>
        <p>{{ $mission['p1'] ?? '' }}</p>
        <p>{{ $mission['p2'] ?? '' }}</p>
        <p class="pull">« {{ $mission['quote'] ?? '' }} »</p>
      </div>
      <div class="mission-figure">
        <img loading="lazy" decoding="async" src="{{ $img(data_get($mission, 'image.src'), 'img/producteur-agent.jpg') }}" alt="{{ data_get($mission, 'image.alt', '') }}">
      </div>
    </div>
  </div>
</section>

<section class="stats reveal" aria-label="Le royaume en chiffres">
  <div class="wrap">
    <div class="stats-grid">
      @foreach ($chiffres as $stat)
        <div class="stat"><b>{{ $stat['value'] ?? '' }}</b><span>{{ $stat['label'] ?? '' }}</span></div>
      @endforeach
    </div>
  </div>
</section>

<section class="section" id="piliers">
  <div class="section-head center reveal">
    <p class="eyebrow center">{{ $piliers['eyebrow'] ?? '' }}</p>
    <h2>{{ $piliers['title'] ?? '' }}</h2>
    <p class="lead">{{ $piliers['lead'] ?? '' }}</p>
  </div>
  <div class="wrap">
    <div class="pillars reveal">
      @foreach (($piliers['cards'] ?? []) as $i => $card)
        <article class="pillar">
          <div class="ph"><img loading="lazy" decoding="async" src="{{ $img(data_get($card, 'image.src')) }}" alt="{{ data_get($card, 'image.alt', '') }}"></div>
          <div class="pb">
            <span class="num">{{ str_pad($i + 1, 2, '0', STR_PAD_LEFT) }}</span>
            <h3>{{ $card['title'] ?? '' }}</h3>
            <p>{{ $card['text'] ?? '' }}</p>
            <a href="{{ $piliersLinks[$i][0] ?? '#' }}" class="go">{{ $piliersLinks[$i][1] ?? __('site.pillar_links.default') }}</a>
          </div>
        </article>
      @endforeach
    </div>
  </div>
</section>

<section class="placali" id="placali">
  <div class="wrap">
    <div class="placali-copy reveal">
      <p class="eyebrow">{{ $placali['eyebrow'] ?? '' }}</p>
      <h2>{{ $placali['title'] ?? 'Placali du Roi' }}</h2>
      <p class="lead">{{ $placali['text'] ?? '' }}</p>
      <div class="placali-tags">
        @foreach (($placali['atouts'] ?? []) as $atout)
          <span>{{ $atout }}</span>
        @endforeach
      </div>
      <div class="placali-price">
        <b>{{ $placali['price'] ?? '' }}</b><span>{{ $placali['price_detail'] ?? '' }}</span>
      </div>
      <a href="{{ route('login') }}" class="btn gold">{{ $placali['button'] ?? 'Commander le Placali du Roi' }}</a>
    </div>
    <div class="placali-pack reveal">
      <div class="seal">{!! __('site.placali.seal') !!}</div>
      <img loading="lazy" decoding="async" src="{{ $img(data_get($placali, 'image_product.src'), 'img/placali-etal.jpg') }}" alt="{{ data_get($placali, 'image_product.alt', '') }}">
    </div>
  </div>
</section>

<section class="section" id="formations">
  <div class="section-head reveal">
    <p class="eyebrow">{{ $fSection['eyebrow'] ?? 'Formations' }}</p>
    <h2>{{ $fSection['title'] ?? '' }}</h2>
    <p class="lead">{{ $fSection['lead'] ?? '' }}</p>
  </div>
  <div class="wrap">
    <div class="courses reveal">
      @foreach ($formations as $formation)
        <a href="{{ route('formations.show', $formation) }}" class="course" style="text-decoration:none;color:inherit">
          <div class="ph">
            <img loading="lazy" decoding="async" src="{{ $img($formation->image_path) }}" alt="{{ $formation->title }}">
            <span class="tag{{ $formation->isFree() ? ' free' : '' }}">{{ $formation->isFree() ? __('site.formation.free_tag') : __('site.formation.premium_tag') }}</span>
          </div>
          <div class="cb">
            <h3>{{ $formation->title }}</h3>
            <div class="meta">
              <span>{{ $formation->lessons_count }} {{ $formation->lessons_count > 1 ? __('site.formation.lessons_plural') : __('site.formation.lessons_singular') }}</span>
              @if ($formation->duration_label)<span>{{ $formation->duration_label }}</span>@endif
            </div>
            <span class="price{{ $formation->isFree() ? ' free' : '' }}">{{ $formation->isFree() ? __('site.formation.free_tag') : $fcfa($formation->price) }}</span>
          </div>
        </a>
      @endforeach
    </div>
    <div class="market-foot reveal">
      <a href="{{ route('formations.index') }}" class="btn">{{ __('site.formation.see_all_button') }}</a>
    </div>
  </div>
</section>

<section class="section market" id="marketplace">
  <div class="section-head reveal">
    <p class="eyebrow">{{ $mSection['eyebrow'] ?? 'Marketplace' }}</p>
    <h2>{{ $mSection['title'] ?? '' }}</h2>
    <p class="lead">{{ $mSection['lead'] ?? '' }}</p>
  </div>
  <div class="wrap">
    <div class="offers reveal">
      @foreach ($offers as $offer)
        <article class="offer">
          <div class="ph"><img loading="lazy" decoding="async" src="{{ $img($offer['image']) }}" alt="{{ $offer['title'] }}"></div>
          <div class="ob">
            <span class="t">{{ $offer['label'] }}</span>
            <h4>{{ $offer['title'] }}</h4>
            <p class="loc">{{ $offer['location'] }}</p>
            <div class="ofoot">
              <span class="p">{{ $offer['price'] }}</span>
              <a href="{{ route('login') }}" class="order">{{ __('site.marketplace.order_button') }}</a>
            </div>
          </div>
        </article>
      @endforeach
    </div>
    <div class="market-foot reveal">
      <a href="{{ route('marketplace.index') }}" class="btn">{{ __('site.marketplace.see_all_button') }}</a>
    </div>
  </div>
</section>

<section class="section" id="communaute">
  <div class="section-head reveal">
    <p class="eyebrow">{{ $communaute['eyebrow'] ?? 'La communauté' }}</p>
    <h2>{{ $communaute['title'] ?? '' }}</h2>
    <p class="lead">{{ $communaute['lead'] ?? '' }}</p>
  </div>
  <div class="wrap">
    <div class="community-grid reveal">
      @foreach ($testimonials as $t)
        <figure class="quote">
          <p>« {{ $t->localized('quote') }} »</p>
          <figcaption class="who">
            <span class="av">{{ $initials($t->author_name) }}</span>
            <span class="who-name"><b>{{ $t->author_name }}</b><span>{{ $t->localized('author_role') }}</span></span>
          </figcaption>
        </figure>
      @endforeach
    </div>
    <div class="community-photo reveal">
      <img loading="lazy" decoding="async" src="{{ $img(data_get($communaute, 'image.src'), 'img/communaute-champ.jpg') }}" alt="{{ data_get($communaute, 'image.alt', '') }}">
    </div>
  </div>
</section>

<section class="section" id="distinctions">
  <div class="wrap">
    <div class="awards reveal">
      <div>
        <p class="eyebrow">{{ $distinctions['eyebrow'] ?? 'Reconnaissance' }}</p>
        <h2>{{ $distinctions['title'] ?? '' }}</h2>
        <div class="award-list">
          @foreach ($awards as $award)
            <div class="award">
              <span class="yr">{{ $award->year }}</span>
              <div><b>{{ $award->localized('title') }}</b><p>{{ $award->localized('description') }}</p></div>
            </div>
          @endforeach
        </div>
      </div>
      <div class="award-figure">
        <img loading="lazy" decoding="async" src="{{ $img(data_get($distinctions, 'image.src'), 'img/ceremonie-attestations.jpg') }}" alt="{{ data_get($distinctions, 'image.alt', '') }}">
      </div>
    </div>
  </div>
</section>

<section class="founder" id="fondateur">
  <div class="wrap">
    <div class="founder-figure">
      <img loading="lazy" decoding="async" src="{{ $img(data_get($fondateur, 'image.src'), 'img/fondateur-conference.jpg') }}" alt="{{ data_get($fondateur, 'image.alt', '') }}">
    </div>
    <div>
      <p class="eyebrow">{{ $fondateur['eyebrow'] ?? 'Le fondateur' }}</p>
      <blockquote>« {{ $fondateur['quote'] ?? '' }} »</blockquote>
      <p class="sig">{{ $fondateur['name'] ?? '' }}</p>
      <p class="role">{{ $fondateur['role'] ?? '' }}</p>
    </div>
  </div>
</section>

<section class="section final" id="rejoindre">
  <div class="wrap">
    <p class="eyebrow center">{{ $ctaFinal['eyebrow'] ?? 'Rejoindre le royaume' }}</p>
    <h2>{{ $ctaFinal['title'] ?? '' }}</h2>
    <p class="lead">{{ $ctaFinal['lead'] ?? '' }}</p>
    <div class="final-actions">
      <a href="{{ route('register') }}" class="btn gold">{{ $ctaFinal['button1'] ?? 'Créer mon compte gratuit' }}</a>
      <a href="{{ route('contact') }}" class="btn ghost">{{ $ctaFinal['button2'] ?? 'Nous contacter' }}</a>
    </div>
  </div>
</section>

</main>

</x-public-layout>
