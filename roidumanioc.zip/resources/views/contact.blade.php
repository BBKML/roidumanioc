{{-- Formulaire de contact — vitrine (Phase 2). --}}
<x-public-layout :title="__('site.contact.title')" :description="__('site.contact.description')">

@php
    $pied = $content['pied'] ?? [];
@endphp

<main id="main">
<span id="top"></span>

<section class="section">
  <div class="wrap">
    <div class="contact-wrap">
      <p class="eyebrow">{{ __('site.contact.eyebrow') }}</p>
      <h1>{{ __('site.contact.heading') }}</h1>
      <p class="contact-lead">{!! __('site.contact.lead') !!}</p>

      @if (session('contact_sent'))
        <div class="alert-ok" role="status">{{ session('contact_sent') }}</div>
      @endif

      <form method="POST" action="{{ route('contact.send') }}" class="contact-form">
        @csrf

        <div class="hp" aria-hidden="true">
          <label>{{ __('site.contact.honeypot_label') }}<input type="text" name="website" tabindex="-1" autocomplete="off"></label>
        </div>

        <div class="row">
          <div class="field">
            <label for="name">{{ __('site.contact.full_name') }}</label>
            <input type="text" id="name" name="name" value="{{ old('name') }}" required maxlength="120">
            @error('name')<span class="err">{{ $message }}</span>@enderror
          </div>
          <div class="field">
            <label for="email">{{ __('site.contact.email') }}</label>
            <input type="email" id="email" name="email" value="{{ old('email') }}" required maxlength="180">
            @error('email')<span class="err">{{ $message }}</span>@enderror
          </div>
        </div>

        <div class="row">
          <div class="field">
            <label for="phone">{{ __('site.contact.phone') }}</label>
            <input type="text" id="phone" name="phone" value="{{ old('phone') }}" maxlength="40">
            @error('phone')<span class="err">{{ $message }}</span>@enderror
          </div>
          <div class="field">
            <label for="subject">{{ __('site.contact.subject') }}</label>
            <input type="text" id="subject" name="subject" value="{{ old('subject') }}" maxlength="160">
            @error('subject')<span class="err">{{ $message }}</span>@enderror
          </div>
        </div>

        <div class="field">
          <label for="message">{{ __('site.contact.message') }}</label>
          <textarea id="message" name="message" required minlength="10" maxlength="4000">{{ old('message') }}</textarea>
          @error('message')<span class="err">{{ $message }}</span>@enderror
        </div>

        <div class="hero-actions">
          <button type="submit" class="btn gold">{{ __('site.contact.submit') }}</button>
          <a href="{{ route('home') }}" class="btn ghost">{{ __('site.contact.back_home') }}</a>
        </div>
      </form>

      <div class="contact-side">
        @if (!empty($pied['email']))
          <span>E-mail&nbsp;: <a href="mailto:{{ $pied['email'] }}">{{ $pied['email'] }}</a></span>
        @endif
        @if (!empty($pied['city']))
          <span>{{ $pied['city'] }}</span>
        @endif
      </div>
    </div>
  </div>
</section>

</main>

</x-public-layout>
