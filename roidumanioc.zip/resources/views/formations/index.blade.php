@php
    $img = fn ($path, $fallback = 'img/champ-manioc.jpg') => asset($path ?: $fallback);
    $fcfa = fn ($n) => number_format((int) $n, 0, ',', ' ').' FCFA';
@endphp
<x-public-layout :title="$section['title'] ?? 'Formations'" :description="$section['lead'] ?? null">

<main id="main">
<span id="top"></span>

<section class="section">
  <div class="wrap">
    <div class="contact-wrap">
      <p class="eyebrow">{{ $section['eyebrow'] ?? 'Formations' }}</p>
      <h1>{{ $section['title'] ?? 'Apprendre le manioc, sérieusement.' }}</h1>
      <p class="contact-lead">{{ $section['lead'] ?? '' }}</p>
    </div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="courses">
      @forelse ($formations as $formation)
        <a href="{{ route('formations.show', $formation) }}" class="course" style="text-decoration:none;color:inherit">
          <div class="ph">
            <img loading="lazy" decoding="async" src="{{ $img($formation->image_path) }}" alt="{{ $formation->title }}">
            <span class="tag{{ $formation->isFree() ? ' free' : '' }}">{{ $formation->isFree() ? __('site.formation.free_tag') : __('site.formation.premium_tag') }}</span>
          </div>
          <div class="cb">
            <h3>{{ $formation->title }}</h3>
            <div class="meta">
              <span>{{ $formation->lessons_count }} {{ $formation->lessons_count > 1 ? __('site.formation.lessons_plural') : __('site.formation.lessons_singular') }}</span>
              @if ($formation->duration_label)<span>{{ $formation->duration_label }}</span>@endif
            </div>
            <span class="price{{ $formation->isFree() ? ' free' : '' }}">{{ $formation->isFree() ? __('site.formation.free_tag') : $fcfa($formation->price) }}</span>
          </div>
        </a>
      @empty
        <p class="muted">Aucune formation publiée pour le moment.</p>
      @endforelse
    </div>
  </div>
</section>

</main>

</x-public-layout>
