@php
    $img = fn ($path, $fallback = 'img/champ-manioc.jpg') => asset($path ?: $fallback);
    $initials = fn ($name) => \Illuminate\Support\Str::of($name)
        ->explode(' ')
        ->filter()
        ->map(fn ($w) => \Illuminate\Support\Str::upper(\Illuminate\Support\Str::substr($w, 0, 1)))
        ->take(2)
        ->implode('');
@endphp
<x-public-layout :title="$content['title'] ?? 'La communauté'" :description="$content['lead'] ?? null">

<main id="main">
<span id="top"></span>

<section class="section">
  <div class="section-head">
    <p class="eyebrow">{{ $content['eyebrow'] ?? 'La communauté' }}</p>
    <h1>{{ $content['title'] ?? 'On avance mieux ensemble.' }}</h1>
    <p class="lead">{{ $content['lead'] ?? '' }}</p>
  </div>
  <div class="wrap">
    <div class="community-grid">
      @forelse ($testimonials as $t)
        <figure class="quote">
          <p>« {{ $t->localized('quote') }} »</p>
          <figcaption class="who">
            <span class="av">{{ $initials($t->author_name) }}</span>
            <span class="who-name"><b>{{ $t->author_name }}</b><span>{{ $t->localized('author_role') }}</span></span>
          </figcaption>
        </figure>
      @empty
        <p class="muted">Aucun témoignage pour le moment.</p>
      @endforelse
    </div>
    <div class="community-photo">
      <img loading="lazy" decoding="async" src="{{ $img(data_get($content, 'image.src'), 'img/communaute-champ.jpg') }}" alt="{{ data_get($content, 'image.alt', '') }}">
    </div>
  </div>
</section>

</main>

</x-public-layout>
