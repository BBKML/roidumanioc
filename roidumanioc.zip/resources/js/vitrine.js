// Vitrine — en-tête au scroll, menu mobile, révélations.
(function(){
  var header=document.getElementById('header');
  var onScroll=function(){header.classList.toggle('scrolled',window.scrollY>12);};
  onScroll();window.addEventListener('scroll',onScroll,{passive:true});

  var toggle=document.getElementById('navToggle');
  var menu=document.getElementById('mobileMenu');
  var setMenu=function(open){
    menu.classList.toggle('open',open);
    toggle.setAttribute('aria-expanded',open?'true':'false');
    toggle.setAttribute('aria-label',open?'Fermer le menu':'Ouvrir le menu');
    document.body.style.overflow=open?'hidden':'';
  };
  toggle.addEventListener('click',function(){setMenu(!menu.classList.contains('open'));});
  menu.addEventListener('click',function(e){if(e.target.tagName==='A')setMenu(false);});

  if(window.matchMedia&&window.matchMedia('(prefers-reduced-motion: no-preference)').matches){
    var io=new IntersectionObserver(function(entries){
      entries.forEach(function(en){if(en.isIntersecting){en.target.classList.add('in');io.unobserve(en.target);}});
    },{threshold:.12,rootMargin:'0px 0px -8% 0px'});
    document.querySelectorAll('.reveal').forEach(function(el){io.observe(el);});
  }
})();
