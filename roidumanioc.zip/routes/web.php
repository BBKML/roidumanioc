<?php

use App\Http\Controllers\Admin\NewsletterExportController;
use App\Http\Controllers\Auth\GoogleController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\FormationsController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LessonMediaController;
use App\Http\Controllers\MarketplaceController;
use App\Http\Controllers\NewsletterController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\PaymentProofController;
use App\Http\Controllers\RegistrationFormController;
use App\Http\Controllers\SitemapController;
use App\Livewire\Account\Settings as AccountSettings;
use App\Livewire\Admin\ActivityLog as AdminActivityLog;
use App\Livewire\Admin\Members as AdminMembers;
use App\Livewire\Admin\CommunityModeration;
use App\Livewire\Admin\ContentManager;
use App\Livewire\Admin\Dashboard as AdminDashboard;
use App\Livewire\Admin\Events as AdminEvents;
use App\Livewire\Admin\Formations as AdminFormations;
use App\Livewire\Admin\LessonManager;
use App\Livewire\Admin\MarketplaceModeration;
use App\Livewire\Admin\Messages as AdminMessages;
use App\Livewire\Admin\Newsletter as AdminNewsletter;
use App\Livewire\Admin\Orders as AdminOrders;
use App\Livewire\Admin\Payments as AdminPayments;
use App\Livewire\Admin\PaymentSettings;
use App\Livewire\Admin\RegistrationFormBuilder;
use App\Livewire\Admin\RegistrationForms as AdminRegistrationForms;
use App\Livewire\Admin\RegistrationLeads as AdminRegistrationLeads;
use App\Livewire\Admin\ShopProducts;
use App\Livewire\Learner\Catalog;
use App\Livewire\Learner\Checkout;
use App\Livewire\Learner\Community as LearnerCommunity;
use App\Livewire\Learner\CourseViewer;
use App\Livewire\Learner\Dashboard as LearnerDashboard;
use App\Livewire\Learner\ListingCheckout;
use App\Livewire\Learner\Marketplace as LearnerMarketplace;
use App\Livewire\Learner\Orders as LearnerOrders;
use App\Livewire\Learner\Progress as LearnerProgress;
use App\Livewire\Learner\ShopCheckout;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Site public (vitrine)
|--------------------------------------------------------------------------
*/
Route::get('/', [HomeController::class, 'index'])->name('home');

Route::get('/langue/{locale}', function (string $locale) {
    abort_unless(in_array($locale, config('locales.supported'), true), 404);

    Cookie::queue(Cookie::forever('locale', $locale));

    return back();
})->name('locale.switch');

Route::get('/contact', [ContactController::class, 'show'])->name('contact');
Route::post('/contact', [ContactController::class, 'send'])
    ->middleware('throttle:6,1')
    ->name('contact.send');

// Catalogue et marketplace consultables publiquement (l'inscription/connexion n'est requise
// qu'au moment de s'inscrire à une formation ou de commander) + pages dédiées ex-ancres.
Route::get('/formations', [FormationsController::class, 'index'])->name('formations.index');
Route::get('/formations/{formation:slug}', [FormationsController::class, 'show'])->name('formations.show');
Route::get('/marketplace', [MarketplaceController::class, 'index'])->name('marketplace.index');
Route::get('/placali', [PageController::class, 'placali'])->name('placali.show');
Route::get('/communaute', [PageController::class, 'communaute'])->name('communaute.show');
Route::get('/fondateur', [PageController::class, 'fondateur'])->name('fondateur.show');

Route::post('/newsletter', [NewsletterController::class, 'store'])
    ->middleware('throttle:6,1')
    ->name('newsletter.store');

Route::get('/sitemap.xml', SitemapController::class)->name('sitemap');

// Pages d'inscription publiques (campagnes réseaux sociaux) — lien partagé, contenu géré
// depuis l'admin (Admin\RegistrationForms).
Route::get('/inscription/{form:slug}', [RegistrationFormController::class, 'show'])->name('inscription.show');
Route::get('/inscription/{form:slug}/affiche', [RegistrationFormController::class, 'image'])->name('inscription.image');
Route::post('/inscription/{form:slug}', [RegistrationFormController::class, 'store'])
    ->middleware('throttle:6,1')
    ->name('inscription.store');

/*
|--------------------------------------------------------------------------
| Redirection après connexion — selon le rôle
|--------------------------------------------------------------------------
*/
Route::get('/dashboard', DashboardController::class)->middleware('auth')->name('dashboard');

/*
|--------------------------------------------------------------------------
| Espace apprenant
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'active'])->prefix('mon-espace')->name('learner.')->group(function () {
    Route::get('/', LearnerDashboard::class)->name('dashboard');
    Route::get('/catalogue', Catalog::class)->name('catalog');
    Route::get('/formations/{formation}', CourseViewer::class)->name('course');
    Route::get('/formations/{formation}/paiement', Checkout::class)->name('checkout');
    Route::get('/boutique/{product}/paiement', ShopCheckout::class)->name('shop-checkout');
    Route::get('/marketplace/{listing}/commander', ListingCheckout::class)->name('listing-checkout');
    Route::get('/progression', LearnerProgress::class)->name('progress');
    Route::get('/marketplace', LearnerMarketplace::class)->name('marketplace');
    Route::get('/commandes', LearnerOrders::class)->name('orders');
    Route::get('/communaute', LearnerCommunity::class)->name('community');
});

// Capture de paiement — accessible à l'admin et au propriétaire (contrôle dans le contrôleur).
Route::middleware('auth')->get('/paiements/{payment}/preuve', PaymentProofController::class)->name('payments.proof');

// Médias de leçon — vidéo téléversée & ressources, gardés par l'inscription (FormationPolicy@follow).
Route::middleware('auth')->group(function () {
    Route::get('/lecons/{lesson}/video', [LessonMediaController::class, 'video'])->name('lessons.video');
    Route::get('/ressources/{attachment}', [LessonMediaController::class, 'attachment'])->name('lessons.attachment');
});

/*
|--------------------------------------------------------------------------
| Connexion Google (OAuth2)
|--------------------------------------------------------------------------
*/
Route::middleware('guest')->group(function () {
    Route::get('/auth/google/redirect', [GoogleController::class, 'redirect'])
        ->middleware('throttle:10,1')->name('google.redirect');
    Route::get('/auth/google/callback', [GoogleController::class, 'callback'])
        ->middleware('throttle:10,1')->name('google.callback');
});

/*
|--------------------------------------------------------------------------
| Mon compte (apprenant & admin)
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'active'])->get('/mon-compte', AccountSettings::class)->name('account.edit');

/*
|--------------------------------------------------------------------------
| Administration
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', AdminDashboard::class)->name('dashboard');

    // Phase 5 — vérification des paiements & commandes
    Route::get('/paiements', AdminPayments::class)->name('payments');
    Route::get('/commandes', AdminOrders::class)->name('orders');

    // Phase 3 — contenu & catalogue
    Route::get('/contenu', ContentManager::class)->name('content');
    Route::get('/formations', AdminFormations::class)->name('formations');
    Route::get('/formations/{formation}/lecons', LessonManager::class)->name('lessons');
    Route::get('/marketplace', MarketplaceModeration::class)->name('marketplace');
    Route::get('/boutique', ShopProducts::class)->name('shop');
    Route::get('/evenements', AdminEvents::class)->name('events');
    Route::get('/communaute', CommunityModeration::class)->name('community');
    Route::get('/parametres', PaymentSettings::class)->name('settings');

    // Phase 6 — comptes & rôles
    Route::get('/membres', AdminMembers::class)->name('members');

    // Phase 7 — audit
    Route::get('/journal', AdminActivityLog::class)->name('activity');

    // Site dynamique — messages & infolettre
    Route::get('/messages', AdminMessages::class)->name('messages');
    Route::get('/infolettre', AdminNewsletter::class)->name('newsletter');
    Route::get('/infolettre/export', NewsletterExportController::class)->name('newsletter.export');

    // Campagnes — formulaires d'inscription publics & prospects captés
    Route::get('/inscriptions/formulaires', AdminRegistrationForms::class)->name('registration-forms');
    Route::get('/inscriptions/formulaires/nouveau', RegistrationFormBuilder::class)->name('registration-forms.create');
    Route::get('/inscriptions/formulaires/{form:slug}/edition', RegistrationFormBuilder::class)->name('registration-forms.edit');
    Route::get('/inscriptions/prospects', AdminRegistrationLeads::class)->name('registration-leads');
});

require __DIR__.'/auth.php';
